#!/bin/bash

#check for the correct number of args
if [ $# -ne 5 ]
then
    echo "Error in $0 - Invalid Argument Count"
    echo "Syntax: $0  <originalBAMFile> <refseq> <uniquePrefix> <# threads> <MAPQ cutoff>"
    exit
fi

#==================COMMAND LINE PARAMETERS==================

#path to the initial, pre-GATK BAM  file
#MUST contain read group tags and header!
originalBAMFile=$1

#path to the FASTA file with the reference sequence
#a .dict and a .fai file need to have been generated prior to running this script and need to reside in the same dir as the FASTA file itself
#the naming of these must be e.g.
#refseq.fa
#refseq.fa.fai
#refseq.dict
refseq=$2

#a unique prefix that will allow the computation to happen in the same directory as other runs without overwriting one another's results
uniquePrefix=$3

#the number of threads we want to use
threads=$4

#a value for the MAPQ we want use for filtering readsduring variant calling 
MAPQ=$5


#==================FIXED PARAMETERS==================
pathToPicard=/mnt/apps/picard/picard-tools-1.119
pathToGATK=/mnt/apps/gatk/3.3.0



#====================GO PROCESS=======================

echo "GATK pipeline run - no BQ recalibration included"
echo "command line args used:"
 for i in $*; do 
   echo $i 
 done

echo "Running the Picard duplicate markup "
java -jar $pathToPicard/MarkDuplicates.jar INPUT=$originalBAMFile OUTPUT=$uniquePrefix.deduped.bam METRICS_FILE=$uniquePrefix.metrics.txt AS=true MAX_FILE_HANDLES_FOR_READ_ENDS_MAP=1000

echo "Indexing the deduped file"
samtools index $uniquePrefix.deduped.bam

echo "Indel realignment step 1 - generating target interval list"
java -jar $pathToGATK/GenomeAnalysisTK.jar -T RealignerTargetCreator -R $refseq -I $uniquePrefix.deduped.bam -o $uniquePrefix.target_intervals.list -nt $threads

echo "Indel realignment step 2 - realigning"
java -jar $pathToGATK/GenomeAnalysisTK.jar -T IndelRealigner -R $refseq -I $uniquePrefix.deduped.bam -targetIntervals $uniquePrefix.target_intervals.list -o $uniquePrefix.realigned.bam

echo "Running the haplotyper"
java -jar $pathToGATK/GenomeAnalysisTK.jar -T HaplotypeCaller -R $refseq -I $uniquePrefix.realigned.bam -o $uniquePrefix.GATK.vcf -nct $threads -mmq $MAPQ

echo "DONE"