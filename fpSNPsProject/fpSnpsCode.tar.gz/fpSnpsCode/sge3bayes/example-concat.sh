#!/bin/bash

#$ -cwd
#$ -V
#$ -N sge3bayes


# The path to Java 7 (or later).
JAVA=/mnt/apps/java/current/bin/java

# The command takes two (required parameters):
# -d --dir      path to the directory containing vcf files
# -o --output   file to create containing the concatenated results
$JAVA -cp lib/pfb.jar sge3bayes.Concat --dir [vcf files] --output [result.txt]