#!/bin/bash
rm *.sam
