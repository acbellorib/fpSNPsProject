#!/bin/bash
lsof -u ar41690 | wc -l > lsof.log
