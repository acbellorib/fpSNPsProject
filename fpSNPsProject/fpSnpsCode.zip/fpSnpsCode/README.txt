GATK scripts:
=============

Two versions are available in the misc_scripts folder of the provided fpSnpsCode.tar.gz package (if the regular GATK_pipeline.sh does not finish correctly due to PICARD validation errors, the user can try the LENIENT_GATK_pipeline.sh version). If other errors still persist when trying to clear the GATK stage, please refer to http://gatkforums.broadinstitute.org/ for tips and help.

The pipeline needs to be run for each BAM file separately and performs duplicate markup with Picard, local realignment around indels, and variant calling with GATK (assuming an already properly working GATK installation is available and the corresponding paths to it are edited in the provided script).

Syntax: ./GATK_pipeline.sh  <originalBAMFile> <refseq> <uniquePrefix> <# threads> <MAPQ cutoff>

where:

<originalBAMFile> is the original BAM file, with read group tags and headers added, even if it only contains a single sample - GATK requires this.
<refseq> The reference sequence in FASTA format, plus a .dict and a .fai files (see below for how to generate).
<uniquePrefix> A unique prefix that will be used to identify this run's outputs. If this is truly unique then multiple runs of the pipeline can be started from within the same directory without results being overwritten across runs.
<# threads> Number of threads to use. The RealignerTargetCreator and HaplotypeCaller steps are multithreadable, the rest is not.
<MAPQ cutoff> The MAPQ cutoff to be used for read filtering during the variant calling.

To generate the .dict and .fai files for the reference (only needs to be done once per reference sequence):

java -jar /mnt/apps/picard/picard-tools-1.119/CreateSequenceDictionary.jar R=refseq.fa O=refseq.dict

samtools faidx refseq.fa

************************************************************************************************************************************************************************
sge3bayes package (available in the sge3bayes folder of the provided fpSnpsCode.tar.gz package):
================================================================================================

sge3bayes/example-main.sh has instructions for running Freebayes in parallel.
sge3bayes/example-concat.sh has instructions for concatenating the .vcf files produced after running Freebayes in parallel.

************************************************************************************************************************************************************************
Filtering of SNPs by depth:
===========================

An example script Multi_FilterVCF_over_VCF_Files.sh was left available under the misc_scripts folder of the provided fpSnpsCode.tar.gz package. Basically, the script expects to be issued under a folder with one or more .VCF files and uses the utils.snps.filtering.FilterVCF application (left available under the utils.jar library) to remove all SNPs with a depth of more than 150.

************************************************************************************************************************************************************************
Counting of SNPs (bi-allelic only) and filtering by SNP score:
==============================================================

An example script countSNPsInVCF_v2WithSNPScoreFilter.sh was also left available under the misc_scripts folder of the provided fpSnpsCode.tar.gz package. Basically, the script expects to be issued over a given .VCF file to count only straight bi-allelic SNPs with a SNP quality score equal or higher than 20. The script will produce an output file of type .vcf.countedList_v2WithSNPScoreFilter which can be used as the input for the mismapping quantifier package detailed below.

************************************************************************************************************************************************************************
Mismapping quantifier package (version fps_02.jar - 13/07/2015):
================================================================

This package has been developed just for this specific study. It's being released for the sake of reproducibility and future work may eventually improve it. 
Comments/suggestions are welcome at antonio.ribeiro@hutton.ac.uk .

Observation: SAMTOOLS and BLASTN are "hard-coded" within the package. Please, ensure that SAMTOOLS is added to your PATH environment variable. For BLASTN, as an example, the code expects the following path structure: 

/mnt/shared/bio_software/ncbi-blast-2.2.28+/bin/blastn

USAGE FOR A TYPICAL REPLICATE RUN (when the reference, in this study, was a given Allpaths-LG or Velvet replicate assembly):
----------------------------------------------------------------------------------------------------------------------------

Observation: The code will produce a significant number of intermediate files before finally generating the resulting tabulated output text file. It is recommended to create a specific folder for a given run to receive the intermediate/output files and issue the command from that folder, while monitoring regularly the disk space consumption. For monitoring and housekeeping purposes, the code also expects the scripts testScript.sh and deleteSAMs.sh to be placed in the immediate upper level directory from the one where the code is being executed.

Usage (command issued from a previously defined folder created to receive the output files): 

java -Djava.ext.dirs=../fpSnpsCode/lib fps.RegionQuantifier <List of SNPs file> <FASTA file> <Truncate name at space character? true | false> <BAM file> <Read length of the simulated dataset> <outputFile> <Run BLAST against any specific database? true | false> <Target BLAST database file | none>

where:

<List of SNPs file> is the output file of type .vcf.countedList_v2WithSNPScoreFilter (produced by the previous "Counting of SNPs (bi-allelic only) and filtering by SNP score" step).
<FASTA file> The reference sequence in FASTA format.
<Truncate name at space character? true | false> set as false in this study.
<BAM file> The mapping file in sorted BAM format (plus a corresponding .bai file available in the same folder of the given .bam file).
<Read length of the simulated dataset> The read length of the simulated dataset which had the reads mapped to the reference sequence being evaluated (e.g 300 for 300 bp).
<outputFile> The name of the aimed output text file to be produced by the code (e.g. 300bp_AT_Allpaths_2ndAssy_BWA_RELAXED_MAPQ20.GATK.vcf.countedList_v2WithSNPScoreFilter_RegQuant.txt).
<Run BLAST against any specific database? true | false> set as true in this study.
<Target BLAST database file | none> The target BLAST database file in FASTA format related to the complete genome from where the simulated reads were originally generated (plus the corresponding ".nin", ".nsq" and ".nhr" index files available in the same folder of the given database file). 

USAGE FOR A CONTROL RUN (when the reference, in this study, was the complete genome from where the simulated reads were originally generated):
----------------------------------------------------------------------------------------------------------------------------------------------

Usage (command issued from a previously defined folder created to receive the output files):

java -Djava.ext.dirs=../fpSnpsCode/lib fps.RegionQuantifierCONTROLS <List of SNPs file> <FASTA file> <Truncate name at space character? true | false> <BAM file> <Read length of the simulated dataset> <outputFile> <Run BLAST against any specific database? true | false> <Target BLAST database file | none>

where:

<List of SNPs file> is the output file of type .vcf.countedList_v2WithSNPScoreFilter (produced by the previous "Counting of SNPs (bi-allelic only) and filtering by SNP score" step).
<FASTA file> The reference sequence in FASTA format.
<Truncate name at space character? true | false> set as false in this study.
<BAM file> The mapping file in sorted BAM format (plus a corresponding .bai file available in the same folder of the given .bam file).
<Read length of the simulated dataset> The read length of the simulated dataset which had the reads mapped to the reference sequence being evaluated (e.g 300 for 300 bp).
<outputFile> The name of the aimed output text file to be produced by the code (e.g. 300bp_AT_2ndCONTROL_Bowtie_RELAXED_MAPQ0_sge3bayes.vcf.countedList_v2WithSNPScoreFilter_RegQuant.txt).
<Run BLAST against any specific database? true | false> set as true in this study.
<Target BLAST database file | none> The target BLAST database file in FASTA format related to the complete genome from where the simulated reads were originally generated (plus the corresponding ".nin", ".nsq" and ".nhr" index files available in the same folder of the given database file).