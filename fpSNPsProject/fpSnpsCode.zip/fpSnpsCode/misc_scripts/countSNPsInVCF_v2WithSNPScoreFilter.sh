#countSNPsInVCF.sh
#script for counting number of straight biallelic SNPs in a VCF file
#based on the length of the REF and ALT allele columns (cols. 4 and 5 in file, 1-based)
#this must be exactly 1 in each case
#multiallelic SNPs will not be counted

#check for the correct number of args
if [ $# -ne 1 ]
then
    echo "Error in $0 - Invalid Argument Count"
    echo "Syntax: $0  <VCFFile> "
    exit
fi


#the VCF input file
VCFFile=$1

#a temp file for storing the SNP count
TEMPFILE=$$.tmp
echo 0 > $TEMPFILE

#another file for storing the output -- this will be a list of the SNPs that we have counted
#outputFile=$VCFFile.countedList
outputFile=$VCFFile.countedList_v2WithSNPScoreFilter

#read the file and split it into lines
cat $VCFFile | while read line; do

	#check if this is a comment line 
	#if it is, we skip it
	if [[ $line == \#* ]]
	then
		continue
	fi
	
	#extract values in cols 4 and 5 and 6 (1-based)
	col4Str=`echo $line | cut -f 4 -d " "`
	col5Str=`echo $line | cut -f 5 -d " "`
	col6=`echo $line | cut -f 6 -d " "`
	
	# debugging block... Please, comment later...
	#echo -e "\nnew line:"
	#echo $col4Str
	#echo $col5Str
	#echo $col6
	#echo ${#col4Str}
	#echo ${#col5Str}
			
	#now check both their lengths are 1 AND that the SNP score value is >= 20
	#if they are, we count it -- it's a proper SNP		
	if [[ ${#col4Str} -eq 1 ]] && [[ ${#col5Str} -eq 1 ]] && [[ ${col6}>=20 ]]
	then
		#increment count
		snpCount=$[$(cat $TEMPFILE) + 1]
		#store it in the temp file
		echo $snpCount > $TEMPFILE
		# echo "incremented SNP count to $snpCount"
		#now append the line containing this SNP to the output file
		echo -e $line >> $outputFile
	fi
	
done
	
echo "final SNP count for file $VCFFile = `cat $TEMPFILE`"
	
# Loop done, script done, delete the file
rm $TEMPFILE

#convert the spaces back into tabs -- the tabs get turned into space characters by the echo command when we output the line
sed -i 's/ /\t/g' $outputFile
#END
