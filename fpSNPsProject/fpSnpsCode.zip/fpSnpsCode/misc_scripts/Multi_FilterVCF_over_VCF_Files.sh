#!/bin/bash
##################################################################################################################
# Script to run VCFFILTER in a bunch of VCF files.
# Author: Antonio Ribeiro * Date: 24/02/2015, based on the tip provided in the webpage: http://seqanswers.com/forums/showthread.php?t=30878
##################################################################################################################

# formatting variables:
filterVCFFileSuffix="_FilteredSNPs.vcf"
#list all the VCF files in directory and iterate over them:

#extract all the filenames to an array
files=`ls -l | awk '{ print $9 }'`

#iterate over these
for i in $files
do
  #extracting extension
  ext=`echo  $i  | sed 's/.*\.//'`
  if [ $ext = "vcf" ]
  then
	#extracting filename without extension...
	fileNameNoExt=`echo $i | basename $i .vcf`
	printf " \n"
	echo "The name of the current VCF file to be processed is: $i"
	printf " \n"
	echo "The basename of this file is: $fileNameNoExt"
	printf " \n"
	# running the command to generate a FILTERED SNPs file:
	#vcffilter -f "DP < 150" rawSNPs.vcf > filteredSNPs.vcf
	#vcffilter -f "DP < 150" $i > $fileNameNoExt$filterVCFFileSuffix
	# using Micha's utils.snps.filtering.FilterVCF tool:
	java utils.snps.filtering.FilterVCF $i DP lt 150 > $fileNameNoExt$filterVCFFileSuffix
  fi
done
printf " \n"
echo "Job is done!"